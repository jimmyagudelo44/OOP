package shipping;

import java.util.Objects;

public abstract class Delivery {

	protected int code;
	protected double weight;
	protected String origin;
	protected String destiny;
	
	public Delivery(int code, double weight, String origin, String destiny) {
		this.code = code;
		this.weight = weight;
		this.destiny = destiny;
	}

	public Delivery() {
		
	}
	
	public int getCode() {
		return code;
	}
	
	public void setCode(int code) {
		this.code = code;
	}
	
	public double getWeight() {
		return weight;
	}
	
	public void setWeight(double weight) {
		this.weight = weight;
	}
	
	public String getDestiny() {
		return destiny;
	}
	
	public void setDestiny(String destiny) {
		this.destiny = destiny;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	@Override
	public String toString() {
		return "Delivery [code=" + code + ", weight=" + weight + ", destiny=" + destiny + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Delivery other = (Delivery) obj;
		return code == other.code;
	}
	
	public abstract double totalCost();
	
}
