package shipping;

public enum State {

	CREATED, SENT, RECEIVED, RETURNED
	
}
