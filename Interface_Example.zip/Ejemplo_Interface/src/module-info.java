/**
 * 
 */
/**
 * 
 */
module Ejemplo_Interface {
}