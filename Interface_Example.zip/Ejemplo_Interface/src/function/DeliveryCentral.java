package function;

import repository.DeliveryRepository;
import shipping.*;
import java.util.Scanner;

public class DeliveryCentral {
	
	private static Scanner KB = new Scanner(System.in);
	private static int code = 0;
	
	public static void listDeliveries() {
		DeliveryRepository.printDeliveries();
	}
	
	public static double totalCost() {
		return DeliveryRepository.totalCost();
	}
	
	public static double insuranceCost() {
		return DeliveryRepository.totalCost();
	}
	
	public static void updateState(State state, int code) {
		DeliveryRepository.updateState(state, code);
	}

	public static void createDelivery() {
		
		System.out.print("Introduce el peso: ");
		double weight = KB.nextDouble();	KB.nextLine();
		System.out.print("Introduce el origen: ");
		String origin = KB.nextLine();
		System.out.print("Introduce el destino: ");
		String destiny = KB.nextLine();
		
		boolean exit = false;
		while(!exit) {
			
			Graphic.deliveryType();
			System.out.print("Selecciona: ");
			int option = KB.nextInt();
			switch(option) {
				case 1->{
					createCase1(weight, origin, destiny);
					exit = true;
				}case 2->{
					createCase2(weight, origin, destiny);
					exit = true;
				}case 3->{
					createCase3(weight, origin, destiny);
					exit = true;
				}case 4->
					exit = true;
				default ->
					System.err.println("Opcion no valida");
			}
		}
	}
	
	private static void createCase1(double weight, String origin, String destiny) {
		System.out.print("Introduce el numero de dias estimados: ");
		int estimatedDays = KB.nextInt();	KB.nextLine();
		DeliveryRepository.createDelivery(
				new StandardDelivery( code++, weight, origin, destiny, estimatedDays));
	}
	
	private static void createCase2(double weight, String origin, String destiny) {
		System.out.print("Introduce el coste extra: ");
		double extraCost = KB.nextDouble();	KB.nextLine();
		DeliveryRepository.createDelivery(
				new UrgentDelivery( code++, weight, origin, destiny, extraCost));
	}
	
	private static void createCase3(double weight, String origin, String destiny) {
		System.out.print("Introduce la temperatura: ");
		double temperature = KB.nextDouble();	KB.nextLine();
		DeliveryRepository.createDelivery(
				new FrozenDelivery( code++, weight, origin, destiny, temperature));
	}
	
	public static void printDeliveries() {
		listDeliveries();
	}
	
	public static Object printTotalCost() {
		return null;
	}

	public static Object printInsuranceTotalCost() {
		return null;
	}

	public static Object updateTrackableDelivery() {
		return null;
	}
	
	
}
